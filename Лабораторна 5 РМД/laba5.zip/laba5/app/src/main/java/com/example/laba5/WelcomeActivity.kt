package com.example.laba5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.laba5.ui.theme.Laba5Theme

class WelcomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val username = intent.getStringExtra("username") ?: "Користувачу"

        setContent {
            Laba5Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFFAF3ED) // ☕ той самий кавовий фон
                ) {
                    WelcomeScreen(username = username, onBack = { finish() })
                }
            }
        }
    }
}

@Composable
fun WelcomeScreen(username: String, onBack: () -> Unit) {
    val coffeeDark = Color(0xFF5C4033)
    val coffeeMedium = Color(0xFFB08A6D)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Вітаємо, $username!",
            fontSize = 28.sp,
            color = coffeeDark,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        Button(
            onClick = { onBack() },
            colors = ButtonDefaults.buttonColors(
                containerColor = coffeeMedium,
                contentColor = Color.White
            )
        ) {
            Text("Назад до реєстрації")
        }
    }
}
