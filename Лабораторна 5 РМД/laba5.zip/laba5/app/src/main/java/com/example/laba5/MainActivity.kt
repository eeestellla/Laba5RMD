package com.example.laba5

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.laba5.ui.theme.Laba5Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Laba5Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFFAF3ED) // ☕ ніжний кавовий фон
                ) {
                    RegistrationScreen(onSuccess = { name ->
                        val intent = Intent(this, WelcomeActivity::class.java)
                        intent.putExtra("username", name)
                        startActivity(intent)
                    })
                }
            }
        }
    }
}

@Composable
fun RegistrationScreen(onSuccess: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    var nameError by remember { mutableStateOf(false) }
    var emailError by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf(false) }

    // Кольори
    val coffeeDark = Color(0xFF5C4033)
    val coffeeMedium = Color(0xFFB08A6D)
    val coffeeLight = Color(0xFFD7BFAE)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Реєстрація",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = coffeeDark,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Ім’я користувача
        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                nameError = false
            },
            label = { Text("Ім’я користувача", color = coffeeDark) },
            isError = nameError,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Email
        OutlinedTextField(
            value = email,
            onValueChange = {
                email = it
                emailError = false
            },
            label = { Text("Email", color = coffeeDark) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            isError = emailError,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Пароль
        OutlinedTextField(
            value = password,
            onValueChange = {
                password = it
                passwordError = false
            },
            label = { Text("Пароль", color = coffeeDark) },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            isError = passwordError,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Кнопка
        Button(
            onClick = {
                var hasError = false
                if (name.isBlank()) {
                    nameError = true
                    hasError = true
                }
                if (email.isBlank() || !email.contains("@")) {
                    emailError = true
                    hasError = true
                }
                if (password.length < 6) {
                    passwordError = true
                    hasError = true
                }

                if (hasError) {
                    errorMessage = "Перевірте правильність заповнення полів"
                } else {
                    errorMessage = ""
                    onSuccess(name)
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = coffeeMedium,
                contentColor = Color.White
            )
        ) {
            Text("Зареєструватися")
        }

        if (errorMessage.isNotEmpty()) {
            Text(
                text = errorMessage,
                color = Color.Red,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
    }
}
